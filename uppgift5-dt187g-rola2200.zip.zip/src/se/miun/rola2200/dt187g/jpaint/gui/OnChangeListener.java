package se.miun.rola2200.dt187g.jpaint.gui;

public interface OnChangeListener<T> {
    void onChange(T value);

}
